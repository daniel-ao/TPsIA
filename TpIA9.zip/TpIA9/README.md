In this tp we had to the goal was to train a model to recognize some kinds of animals using sample images by gathering and uploading images for every class (Animal kind)
So once the model was trained then we could upload some photos to test the model we have.
For this model I made it able to recognize several kinds of animals such like: Birds, Cats, Dogs, Elephants, Fish, Snakes, and Zebras.
Although the model works well for example if we put some pictures of a dog it will say that the animal in the picture is a dog, however if we try to mix some animals in one picture the model won't be able to recogize that(And I added these pictures in a folder named "Other photos for testing"). For example if I upload a picture of an Elephant with the skin of a Zebra it will recognize it as a zebra and it won't give me a 50 50 percent.
So as a conculsion, I think this ai is good for recognizing the animal when it's 100% recognizable, and not the other way around.
